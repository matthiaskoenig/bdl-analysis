library(testthat)
library(caret)

test_check("caret")
