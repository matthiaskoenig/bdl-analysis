/***************************************************************************
 Authors: Henrik Bengtsson

 Copyright Henrik Bengtsson, 2013-2014
 **************************************************************************/
double logSumExp_double(double *x, R_xlen_t nx, int narm, int hasna);
double logSumExp_double_by(double *x, R_xlen_t nx, int narm, int hasna, int by, double *xx);
