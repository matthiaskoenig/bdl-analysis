
void C_TreeGrow(SEXP node, SEXP learnsample, SEXP fitmem,
                SEXP controls, int *where, int *nodenum, int depth);
