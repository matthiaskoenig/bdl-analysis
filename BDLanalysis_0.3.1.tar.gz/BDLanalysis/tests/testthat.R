library(testthat)
library(BDLanalysis)

test_check("BDLanalysis")
