## ----knitr_setup, options, echo=FALSE------------------------------------
knitr::knit_hooks$set(htmlcap = function(before, options, envir) {
  if(!before) {
    paste('<p class="caption">',options$htmlcap,"</p>",sep="")
    }
})

# set the fontsize of chunk via provided latex hook (only for PDF)
# just provide the font size via the fontsize argument, e.g. fontsize="tiny"
knitr::knit_hooks$set(fontsize = function(before, options, envir) {
  if (before) {
    return(paste('\\', options$fontsize, sep = ''))
  } else {
    return(paste('\\normalsize', sep = ''))
  }
})

## ----global_options, include=FALSE---------------------------------------
knitr::opts_chunk$set(fig.width=10, fig.path='Figs/',
                      warning=FALSE, message=FALSE,
                      comment=NA, strip.white=TRUE)

## ----results_path, eval=TRUE, strip.white=TRUE---------------------------
# read results directory from environment variable
resultsPath <- Sys.getenv("BDL_RESULTS")
if (identical(resultsPath, "")){
  stop("No results directory defined, set the BDL_RESULTS environment variable")
}
# create directory to store data sets of analysis
dir.create(file.path(resultsPath, 'data'), showWarnings=FALSE)

## ----bdl_data, eval=TRUE, strip.white=TRUE-------------------------------
suppressPackageStartupMessages(library(BDLanalysis))
suppressPackageStartupMessages(library(calibrate))
suppressPackageStartupMessages(library(pander))
dir.create(file.path(resultsPath, 'control'), showWarnings=FALSE)
# path definition
baseLoc <- system.file(package="BDLanalysis")
extPath <- file.path(baseLoc, "extdata")
# load data
data(BDLdata)
data(BDLsamples)
data(BDLfactors)
data(BDLprobes)
# counters
Nr <- 5  # repeats
Nt <- length(levels(BDLsamples$time_fac))  # Nt=8 time points
# store all data sets in the results folder
save(BDLdata, file=file.path(resultsPath, "data", "BDLdata.Rdata"))
save(BDLsamples, file=file.path(resultsPath, "data", "BDLsamples.Rdata"))
save(BDLfactors, file=file.path(resultsPath, "data", "BDLfactors.Rdata"))
save(BDLprobes, file=file.path(resultsPath, "data", "BDLprobes.Rdata"))

## ----bdl_mean_data-------------------------------------------------------
BDLmean <- bdl_mean_data(BDLdata, BDLsamples)
BDLmean.time <- as.numeric(levels(as.factor(BDLsamples$time)))

## ----factor_table--------------------------------------------------------
cat_table <- as.data.frame(table(BDLfactors$ftype))
colnames(cat_table) <- c("Category", "Freq")
set.caption(sub(".", " ", "Factors per category", fixed = TRUE))
pander(cat_table)
rm(cat_table)

## ----gene_ids------------------------------------------------------------
# create data frame with probe information
create_probe_df <- function() {
  # get the gene factors
  f_names <- colnames(BDLdata)[BDLfactors$ftype.short == ""]
  # get the probe information
  Nf = length(f_names)
  probe_names <- rep(NA, length=Nf)
  probe_uniprot <- rep(NA, length=Nf)
  probe_genes <- rep(NA, length=Nf)
  names(probe_names) <- f_names
  names(probe_uniprot) <- f_names
  names(probe_genes) <- f_names
  for (name in colnames(BDLdata)){
      probe_info <- ProbeInformation(name)
      if (!is.null(probe_info)){
        if (!is.null(probe_info$Protein.name)){
          probe_names[name] <- probe_info$Protein.name
          probe_uniprot[name] <- probe_info$Entry
          probe_genes[name] <- probe_info$Gene.name  
        }
      }
  }
  probe.df <- data.frame(name=probe_names, genes=probe_genes, uniprot=probe_uniprot)
  # sort
  probe.df <- probe.df[order(rownames(probe.df)), ]
  # remove the double Act probes
  probe.df <- probe.df[!(rownames(probe.df) %in% c("Actb.x", "Actb.y")) , ]  
  return(probe.df)
}
# print probe information
probe.df <- create_probe_df()

## ----print_gene_table, fontsize="small"----------------------------------
options(width=200)
print(probe.df)
options(width=75)

## ----factor_plots--------------------------------------------------------
# Create figures for all factors
factors_path <- file.path(resultsPath, 'factors')
dir.create(factors_path, showWarnings=FALSE)
plot_all_factors(path=factors_path)
rm(factors_path)

## ----echo=FALSE----------------------------------------------------------
fig.cap.bilirubin <- "Figure: Bilrubin timecourse. Plot of the raw time course data for bilirubin. On the left the data is plotted against the time [h], on the right against the different time classes. Individual data points are depecticed in blue with the respective sample number shown next to the data points. The mean averaged of the repeats per time point are depicted in red."

## ----bilirubin_plot, htmlcap=fig.cap.bilirubin, fig.cap=fig.cap.bilirubin----
plot_single_factor('bilirubin', path=NULL)

## ----timecourse_heatmap--------------------------------------------------
suppressPackageStartupMessages(library(gplots))
suppressPackageStartupMessages(library(RColorBrewer))

# define horizontal and vertical helper lines
v_lines <- ((1:Nt)*Nr+0.5)
factor_types <- c("Histochemistry", "Biochemistry", 
                  "GE_Fibrosis", "GE_Cytokines", "GE_ADME")
factor_table <- table(BDLfactors$ftype)
h_lines <- 0.5 + cumsum(factor_table[factor_types])

timecourse_heatmap <- function(){
  # create better row names
  dtmp <- BDLdata
  rownames(dtmp) <- paste(rownames(BDLsamples), BDLsamples$time_fac, sep=" ")
  # heatmap colors 
  hmap_colors <- HeatmapColors()
  # colors for factor groups
  colorset <- brewer.pal(length(factor_types), "Set2")
  color.map <- function(factor_id) {
    return(
      colorset[which(factor_types==BDLfactors$ftype[which(BDLfactors$id==factor_id)])]
    )
  }
  factorColors <- unlist(lapply(BDLfactors$id, color.map))
  # heatmap
  heatmap.2(t(as.matrix(dtmp)), col=hmap_colors(100), scale="row", 
            dendrogram="none", Rowv=NULL, Colv=NULL,
            key=TRUE, trace="none", cexRow=0.5, keysize=0.8, density.info="none",
            RowSideColors=factorColors,
            add.expr=abline(v=v_lines, h=h_lines, col="black", lwd=0.5),
            main="Heatmap of BDL time course data")
            # xlab="sample", ylab="factor")
  # legend
  legend("left",
      inset=c(-0.03,0),
      legend = rev(factor_types), # category labels
      col = rev(colorset),  # color key
      lty= 1, lwd = 10, cex = 0.7, bty="n"
  )
}
# plot to file
pdf(file.path(resultsPath, "control", "timecourse_heatmap.pdf"), 
    width=10, height=10, pointsize=12) 
timecourse_heatmap()
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.tc_heatmap_all <- 'Figure: Timecourse heatmap of all factors. Rows correspond to individual factors, with factor order corresponding to the original data set: `GE_ADME`, `GE_Cytokines`, `GE_Fibrosis`, `Biochemistry`, `Histochemistry`. Columns correspond to the 40 samples with 5 subsequent samples belonging to one of the 8 time points. The data is row scaled, i.e. every individual factor is scaled to have mean zero and standard deviation one.'

## ----timecourse_heatmap_report, fig.width=10, fig.height=10, error=TRUE, fig.cap=fig.cap.tc_heatmap_all, htmlcap=fig.cap.tc_heatmap_all----
timecourse_heatmap()

## ----heatmap_clean, echo=FALSE-------------------------------------------
# cleanup
rm(factor_table, h_lines, v_lines)

## ----check_actb----------------------------------------------------------
# Actb control figure
plot_actb_control <- function(){
  par(mfrow=c(2,3))
  plot_single("Actb")
  plot_single("Actb.x")
  plot_single("Actb.y")
  plot_cor_pair("Actb", "Actb.x", single_plots=FALSE)
  plot_cor_pair("Actb", "Actb.y", single_plots=FALSE)
  plot_cor_pair("Actb.x", "Actb.y", single_plots=FALSE)
  par(mfrow=c(1,1))
}

# plot to file
pdf(file.path(resultsPath, "control", "Actb_control.pdf"), 
    width=10, height=6, pointsize=12)  
plot_actb_control()
invisible(dev.off())

# calculate Spearman and Pearson correlation coefficients on N=8*5=40 data points 
actb.spearman <- cor(data.frame(Actb=BDLdata$Actb, 
                                Actb.x=BDLdata$Actb.x, 
                                Actb.y=BDLdata$Actb.y), method="spearman")
actb.pearson <- cor(data.frame(Actb=BDLdata$Actb, 
                               Actb.x=BDLdata$Actb.x, 
                               Actb.y=BDLdata$Actb.y), method="pearson")

# table of correlation coefficients
set.caption(sub(".", " ", "Spearman correlation of Actb controls", fixed = TRUE))
pander(round(actb.spearman, digits=3))
set.caption(sub(".", " ", "Pearson correlation of Actb controls", fixed = TRUE))
pander(round(actb.pearson, digits=3))

## ----echo=FALSE----------------------------------------------------------
fig.cap.actb_control <- 'Figure: Actb control. Correlation plot of the Actb probes from the 3 Fluidigm chips: Actb (fibrosis), Actb.x (ADME), Actb.y (Cytokines). The top row shows the individual time courses, the bottom row the pair wise plot of individual data points.'

## ----actb_control_plot, fig.width=10, fig.height=7,  htmlcap=fig.cap.actb_control, fig.cap=fig.cap.actb_control----
plot_actb_control()

## ----echo=FALSE----------------------------------------------------------
rm(actb.pearson, actb.spearman)

## ----bdl_matrices--------------------------------------------------------
BDLmatrices <- bdl_matrix_data(BDLdata, BDLsamples)

## ----single_anova--------------------------------------------------------
  # example ANOVA for one factor
  mat.anova <- t(BDLmatrices[['bilirubin']])
  colnames(mat.anova) <- levels(BDLsamples$time_fac)
  print(mat.anova)
  
  # concatenate the data rows of df1 into a single vector r .
  r = c(t(as.matrix(mat.anova)))  # response data 
  
  # assign new variables for the treatment levels and number of observations.
  f = levels(BDLsamples$time_fac)   # treatment levels 
  k = Nt                             # number of treatment levels (time points Nt=8) 
  n = Nr                             # observations per treatment (repeats Nr=5)
  
  # vector of treatment factors that corresponds to each element of r 
  # in step 3 with the gl function.
  tm <- gl(k, 1, n*k, factor(f))   # matching treatments 
  
  # apply the function aov to a formula that describes the response r 
  # by the treatment factor tm (fit ANOVA model)
  av <- aov(r ~ tm) 
  
  # print ANOVA summary
  summary(av)
  # print p-value
  p.value <- summary(av)[[1]][["Pr(>F)"]][[1]]

## ----echo=FALSE----------------------------------------------------------
  # cleanup
rm(r, f, k, n, tm, av, p.value, mat.anova) 

## ----anova_all-----------------------------------------------------------
# Calculation of ANOVA for all factors
df.anova <- all_factor_anova()
df.anova$sig <- sapply(df.anova$p.value, significant_code)  # add significant codes

df.anova$p.holm <- p.adjust(df.anova$p.value, method ="holm", 
                            n = length(df.anova$p.value))
df.anova$sig.holm <- sapply(df.anova$p.holm, significant_code) 
df.anova$ftype <- BDLfactors$ftype
df.anova$fshort <- BDLfactors$ftype.short

# order factors by adjusted p-values, and cleanup for printing
df.anova.ordered <- df.anova[with(df.anova, order(p.holm)), ]
rownames(df.anova.ordered) <- df.anova.ordered$factors
df.anova.ordered <- df.anova.ordered[c("p.holm", "sig.holm", "ftype", "fshort")]
df.anova.ordered$p.holm <- as.numeric(sprintf("%1.2E", df.anova.ordered$p.holm))

# save results
write.table(df.anova.ordered, file=file.path(resultsPath, "data", 'BDLanova.csv'), 
            sep="\t", quote=FALSE)
save(df.anova, file=file.path(resultsPath, "data", "BDLanova.Rdata"))

## ----print_anova_all, fontsize="small"-----------------------------------
print(df.anova.ordered)

## ----filter_factors------------------------------------------------------
p.accept = 0.05  # acceptance level
anova.accept = (df.anova$p.holm < p.accept)  # accepted subset
# subset of filtered data
BDLdata.fil <- BDLdata[, anova.accept]
BDLmean.fil <- BDLdata[, anova.accept]

# accepted
table(anova.accept)  # 64 rejected / 90 accepted (adjusted)

# which factors are accepted in which category
fil_tab <- data.frame(
  table(BDLfactors$ftype[anova.accept]),
  table(BDLfactors$ftype),
  round(table(BDLfactors$ftype[anova.accept])/table(BDLfactors$ftype), 2)
)
fil_tab <- fil_tab[, c('Var1', 'Freq', 'Freq.1', 'Freq.2')]
names(fil_tab) <- c('Category', 'Accepted', 'All', 'Percent')
# overview of filtered factors
print(fil_tab)
rm(fil_tab)

## ----heatmap_filtered----------------------------------------------------
# vertical time separators
v_lines <- ((1:Nt)*Nr+0.5)

timecourse_heatmap_filtered <- function(){
  # prepare data with row names
  dtmp <- BDLdata.fil
  rownames(dtmp) <- paste(rownames(BDLsamples), BDLsamples$time_fac, sep=" ")
  
  # color definitions
  hmap_colors <- HeatmapColors()
  colorset <- brewer.pal(length(factor_types), "Set2")
  color.map <- function(factor_id) {
    return(
      colorset[which(factor_types==BDLfactors$ftype[which(BDLfactors$id==factor_id)])]
  )}
  factorColors <- unlist(lapply(colnames(BDLdata.fil), color.map))
  # heatmap
  heatmap.2(t(as.matrix(dtmp)), col=hmap_colors(100), scale="row", dendrogram="none", 
            Rowv=NULL, Colv=NULL,
            key=TRUE, trace="none", cexRow=0.5, keysize=0.8, density.info="none",
            RowSideColors=factorColors,
            add.expr=abline(v=v_lines, col="black", lwd=0.5),
            main="ANOVA Filtered BDL factors")
            # xlab="sample", ylab="factor")
  # legend
  legend("left",
      inset=c(-0.03,0),
      legend = rev(factor_types), # category labels
      col = rev(colorset),   # color key
      lty= 1,                # line style
      lwd = 10,              # line width
      cex = 0.7,
      bty="n"
  )
}

# plot to file
pdf(file.path(resultsPath, "control", "timecourse_heatmap_filtered.pdf"), 
    width=10, height=10, pointsize=12)  
timecourse_heatmap_filtered()
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.tc_heatmap_fil <- 'Figure: Filtered timecourse data. Plot of ANOVA filtered data set with processing analog to Figure above.'

## ----heatmap_filtered_plot, fig.width=10, fig.height=10, error=TRUE, htmlcap=fig.cap.tc_heatmap_fil, fig.cap=fig.cap.tc_heatmap_fil----
# plot to report
timecourse_heatmap_filtered()

## ----echo=FALSE----------------------------------------------------------
rm(v_lines)

## ----t_test--------------------------------------------------------------
# t-test for the initial phase changes
calculate_inital_phase_changes <- function(){
  # init vectors
  p.t_test <- rep(NA, ncol(BDLdata))
  names(p.t_test) <- colnames(BDLdata)
  up_down <- rep(NA, ncol(BDLdata))
  names(up_down) <- colnames(BDLdata)
  
  for (name in colnames(BDLdata)){
    # data for control (0h) and initial response (6h)
    d0 <- BDLdata[BDLsamples$time_fac == "0h", name]
    d6 <- BDLdata[BDLsamples$time_fac == "6h", name]  
    # remove NA (for immunostainings Nr=3)
    d0 <- d0[!is.na(d0)]
    d6 <- d6[!is.na(d6)]
    # unpaired two.sided t-test
    t.test.res <- t.test(d0, d6, alternative="two.sided", var.equal=FALSE)
    p.t_test[name] <- t.test.res$p.value
    # going up or down
    up_down[name] <- "-"
    if (mean(d6) > mean(d0)){
      up_down[name] <- "up"
    } else if (mean(d6) < mean(d0)){
      up_down[name] <- "down"
    }
  }
  # data.frame for t-test results
  p.df <- data.frame(p.value=p.t_test, up_down=up_down)
  p.df$sig <- sapply(p.df$p.value, significant_code) 
  rownames(p.df) <- colnames(BDLdata)
  
  # sort by p.value
  p.df.ordered <- p.df[order(p.df$p.value),]  
  
  return(p.df.ordered)
}

# top up and down regulated in initial phase
p.df.ordered <- calculate_inital_phase_changes() 
p.df.up <- p.df.ordered[p.df.ordered$p.value<0.05 & p.df.ordered$up_down=="up", ]
p.df.down <- p.df.ordered[p.df.ordered$p.value<0.05 & p.df.ordered$up_down=="down", ]

## ----t_test_results, fontsize="small"------------------------------------
# top up
print(p.df.up)
# top down
print(p.df.down)

## ----correlation_methods-------------------------------------------------
suppressPackageStartupMessages(library(corrplot))
dir.create(file.path(resultsPath, 'correlation'), showWarnings=FALSE)

# list of calculated correlation methods
correlation_methods <- c("pearson", "spearman", "ys1", "ys2", "ys3", "yr1", "yr2", "yr3")

# calculated correlation matrices are stored in cor.matrices
cor.matrices <- vector("list", length=length(correlation_methods))
names(cor.matrices) <- correlation_methods

## ----correlation_pearson_spearman----------------------------------------
# Spearman and Pearson on individual data points
cor.matrices$pearson <- cor(BDLdata.fil, method="pearson", use="pairwise.complete.obs")
cor.matrices$spearman <- cor(BDLdata.fil, method="spearman", use="pairwise.complete.obs")

## ----correlation_heatmap_plot--------------------------------------------
# Heatmap of correlation matrix
correlation_heatmap <- function(method){
  data <- cor.matrices[[method]]
  if(is.null(data)){
    stop("Correlation matrix does not exist for method: ", method)
  }
  cor_colors <- HeatmapColors() # color palette for correlation (red - white - blue)
  heatmap.2(data, col=cor_colors(10), scale="none",
          key=TRUE, symkey=FALSE, trace="none", cexRow=0.8, cexCol=0.8,
          main=method,
          density.info="none", dendrogram="none", 
          Rowv=NULL, Colv=NULL, 
          keysize=0.8, key.xlab = method,
          #revC=TRUE,
          sepwidth=c(0.01,0.01),
          sepcolor="black",
          colsep=1:ncol(data),
          rowsep=1:nrow(data))
}

## ----echo=FALSE----------------------------------------------------------
fig.cap.pearson_orginal <- 'Figure: Heatmap of Pearson correlation. Correlation matrix based on Pearson correlation for filtered data set. No clustering was applied.'

## ----heatmap_pearson, fig.width=10, fig.height=10, error=TRUE, htmlcap=fig.cap.pearson_orginal, fig.cap=fig.cap.pearson_orginal----
# Pearson correlation (no clustering)
correlation_heatmap(method="pearson")

## ----echo=FALSE----------------------------------------------------------
fig.cap.spearman_orginal <- 'Figure: Heatmap of Spearman correlation. Correlation matrix based on Spearman correlation for filtered data set. No clustering was applied.'

## ----heatmap_spearman, fig.width=10, fig.height=10, error=TRUE, htmlcap=fig.cap.spearman_orginal, fig.cap=fig.cap.spearman_orginal----
# Spearman correlation (no clustering)
correlation_heatmap(method="spearman")

## ----ys_yr_calculation---------------------------------------------------
# weighting factors
w <- list(w1=0.5, w2=0.3, w3=0.2)

# calculate the YSR component matrices on the filtered data set (A, A*, A**, M, M*)
# all components are calculated on the mean data
ysr.res <- ysr.matrices(BDLmean.fil, BDLmean.time, use="pairwise.complete.obs")

# S* and R* (Pearson & Spearman correlation on individual data points)
cor.S_star <- (cor.matrices$spearman + 1)/2
cor.R_star <- (cor.matrices$pearson + 1)/2

# Calculate YS and YR scores based on the components
ysr_methods <- c("ys1", "ys2", "ys3", "yr1", "yr2", "yr3")
cor.ysr <- vector("list", length(ysr_methods))
names(cor.ysr) <- ysr_methods

# unnormalized correlations in [0, 1] as combination of weighted (S/R, A/A*/A**, M/M*)
cor.ysr$ys1 <- w$w1*cor.S_star + w$w2*ysr.res$A       + w$w3*ysr.res$M
cor.ysr$ys2 <- w$w1*cor.S_star + w$w2*ysr.res$A_star  + w$w3*ysr.res$M_star
cor.ysr$ys3 <- w$w1*cor.S_star + w$w2*ysr.res$A_star2 + w$w3*ysr.res$M_star

cor.ysr$yr1 <- w$w1*cor.R_star + w$w2*ysr.res$A       + w$w3*ysr.res$M
cor.ysr$yr2 <- w$w1*cor.R_star + w$w2*ysr.res$A_star  + w$w3*ysr.res$M_star
cor.ysr$yr3 <- w$w1*cor.R_star + w$w2*ysr.res$A_star2 + w$w3*ysr.res$M_star 

# scaling of ysr correlation coefficient to interval [-1,1]
for (method in ysr_methods){
  cor.matrices[[method]] <- 2*(cor.ysr[[method]]-0.5)
}

# Save correlation matrices
save(cor.matrices, file=file.path(resultsPath, "data", "cor.matrices.Rdata"))
rm(cor.ysr, cor.R_star, cor.S_star, ysr.res, ysr_methods)

## ----all_correlation_plots-----------------------------------------------
# create all correlation heatmaps on disk
hmap.settings <- list(width=10, height=10, pointsize=12)
for (method in correlation_methods){
  fname <- sprintf('cor.%s.pdf', method)
  pdf(file.path(resultsPath, "correlation", fname),
      width=hmap.settings$width, height=hmap.settings$height, 
      pointsize=hmap.settings$pointsize)
  correlation_heatmap(method=method)
invisible(dev.off())
rm(method, fname)
}

## ----echo=FALSE----------------------------------------------------------
fig.cap.ys3_orginal <- 'Figure: Heatmap of YS3 correlation. Correlation matrix based on YS3 correlation for filtered data set. No clustering was applied.'

## ----ys3_correlation_report, fig.width=10, fig.height=10, error=TRUE, htmlcap=fig.cap.ys3_orginal, fig.cap=fig.cap.ys3_orginal----
# ys3 heatmap in report
correlation_heatmap(method="ys3")

## ----hierarchical_clustering---------------------------------------------
hclust.res <- vector("list", length=length(correlation_methods))
names(hclust.res) <- correlation_methods

# Calculate hierarical clustering: N clusters for correlation based on method
calculate_clusters <- function(cor_method, N){
  # get correlation matrix
  cor.cluster <- cor.matrices[[cor_method]]
  # perform hierarchical clustering (complete linkage & Euclidion distance measure)
  hc <- hclust(dist(cor.cluster, method="euclidian"), method="complete") 
  # cut into the clusters
  groups <- cutree(hc, k=Ngroups)
  groups.hc.order <- groups[hc$order]
  # store results
  return(list(hc=hc,
              groups=groups,
              groups.hc.order=groups.hc.order))
}

Ngroups <- 6   # number of clusters
for (method in correlation_methods){
  hclust.res[[method]] <- calculate_clusters(cor_method=method, N=Ngroups)
}
# save clustering
save(hclust.res, file=file.path(resultsPath, "data", "hclust.res.Rdata"))
rm(method)

## ----correlation_heatmap_cluster-----------------------------------------
# Create correlation heatmap with hierachical clustering results
correlation_heatmap_cluster <- function(method){
  # matrix and cluster results
  cor.cluster <- cor.matrices[[method]]
  hc.res <- hclust.res[[method]]
  hc <- hc.res$hc
  groups <- hc.res$groups
  # colors
  hmap_colors <- HeatmapColors()
  colorset <- brewer.pal(Ngroups, "Set1")
  color.map <- function(cluster_id) {return(colorset[cluster_id])}
  clusterColors <- unlist(lapply(groups, color.map))
  
  heatmap.2(cor.cluster, col=hmap_colors(10), scale="none",
          key=TRUE, symkey=FALSE, trace="none", cexRow=0.8, cexCol=0.8,
          main=method,
          density.info="none", dendrogram="column", 
          Rowv=as.dendrogram(hc), Colv=as.dendrogram(hc), 
          keysize=0.8,
          key.xlab=method,
          ColSideColors=clusterColors, revC=TRUE,
          sepwidth=c(0.01,0.01),
          sepcolor="black",
          colsep=1:ncol(cor.cluster),
          rowsep=1:nrow(cor.cluster),
          margins=c(12,8))
  legend("left", legend=paste("c", 1:6, sep=""), 
         col= unlist(lapply(1:6, color.map)), pch=15, bty="n")
}

# plot to files
for(method in correlation_methods){
  pdf(file.path(resultsPath, "correlation", sprintf("cor.%s.hclust.pdf", method)), 
      width=10, height=10, pointsize=12) 
  correlation_heatmap_cluster(method=method)
  invisible(dev.off())  
}
rm(method)

## ----echo=FALSE----------------------------------------------------------
fig.cap.ys3_cluster <- 'Figure: Heatmap of YS3 clustering. Correlation matrix based on YS3 correlation for filtered data set with hierarchical clustering results based on complete linkage.'

## ----heatmap_ys3, fig.width=10, fig.height=10, error=TRUE, htmlcap=fig.cap.ys3_cluster, fig.cap=fig.cap.ys3_cluster----
# plot ys3 clustering to report
correlation_heatmap_cluster(method="ys3")

## ----list_cluster_members------------------------------------------------
# print representatives of cluster
list_cluster_members <- function(method){
  groups <- hclust.res[[method]]$groups
  cat(sprintf("------------------------------------------\n"))
  cat(sprintf("Correlation method: *** %s ***\n", method))
  cat(sprintf("------------------------------------------\n"))
  for (k in 1:Ngroups){
    g <- groups[groups==k]
    cat(sprintf("Cluster %s (N=%s)\n", k, length(g)))
    print(names(g))
    cat("\n")
    # print(paste(names(g), sep=", ", collapse =", " ))
  }  
}

## ----fontsize="small"----------------------------------------------------
list_cluster_members(method="ys3")

## ----correlation_histological--------------------------------------------
get_histological_correlations <- function(method="ys3", cor.cutoff=0.6){
  # correlation matrix
  cor_mat <- cor.matrices[[method]]
  
  # non-transcipt factors accepted by ANOVA
  hist_facs <- BDLfactors$id[anova.accept & 
                (BDLfactors$ftype %in% c("Biochemistry", "Histochemistry"))]
  
  # get indices of these factors in correlation matrix
  hist_idx <- rep(NA, length(hist_facs))
  for (k in 1:length(hist_facs)){
    hist_idx[k] <- which(colnames(cor_mat) == hist_facs[k])
  }
  # subset of correlation matrix for histological markers (corresponding rows)
  hist_data <-  cor_mat[hist_idx, ]  
  
  # filter columns by correlation cutoff
  col.accept <- rep(NA, ncol(hist_data))
  for (k in 1:ncol(hist_data)){
    # keep column if any abs(correlation) >= cutoff in the column
    col.accept[k] <- any( abs(hist_data[,k])>=cor.cutoff )
  }
  # accepted factors
  # print(table(col.accept))
  hist_accept <- hist_data[, col.accept]
  
  # sort by the hierarchical cluster ordering
  hist_gene_names <- colnames(hist_accept)[1:(ncol(hist_accept)-nrow(hist_accept))]

  # correlation based cluster for ordering
  hc.res <- hclust.res[[method]]
  
  # create sort index for gene names based on clustering
  sort_idx <- rep(NA, length(hist_gene_names))
  for (k in 1:length(hist_gene_names)){
    sort_idx[k] <- which(names(hc.res$groups.hc.order) == hist_gene_names[k])
  }
  # first the sort genes, at the end the self correlation of the histological factors
  hist_sorted <- hist_accept[, c(hist_gene_names[order(sort_idx)], rownames(hist_data))]  
  return(hist_sorted)
}

histological_correlations <- get_histological_correlations(method="ys3")

# plot subset of correlations matrix to file
plot_histological_correlations <- function(hist_data){
  hmap_colors <- HeatmapColors()
  corrplot(hist_data, method="circle", type="full", 
           tl.cex=0.7, tl.col="black", col=hmap_colors(10))  
}

# plot to file
pdf(file.path(resultsPath, "correlation", "histological_correlations.pdf"), 
    width=10, height=4, pointsize=12)
plot_histological_correlations(histological_correlations)
invisible(dev.off())

## ----fontsize="small"----------------------------------------------------
# print correlation values
options(width=200)
print(round(t(histological_correlations), digits=2))
options(width=75)

## ----echo=FALSE----------------------------------------------------------
fig.cap.classical_correlations <- 'Figure: Correlations to classical factors. Correlations between transcripts and classical factors, i.e. biochemical and (immuno-)histochemical factors. The genes are filtered based on a cutoff for the correlation, i.e. columns in which no correlation coefficient abs(value) >= cor.cutoff exists are filtered out.'

## ----histological_correlations_plot, fig.width=10, fig.height=4, error=TRUE, htmlcap=fig.cap.classical_correlations, fig.cap=fig.cap.classical_correlations----
plot_histological_correlations(histological_correlations)

## ----plot_hist_topcors---------------------------------------------------
plot_hist_topcors <- function(method="ys3", labels=TRUE, mfrow=c(10,1), 
                              only_RNA=FALSE, Ntop=10){
  hist_facs <- rownames(histological_correlations)
  cor.mat <- cor.matrices[[method]]
  
  # store the results
  top.correlations <- vector("list", length=length(hist_facs))
  names(top.correlations) <- hist_facs
  
  par(mfrow=mfrow)
  hmap_colors <- HeatmapColors()
  for (name in hist_facs){
    if (only_RNA==TRUE){
      # get which which are not classical factors
      v <- cor.mat[!(colnames(cor.mat) %in% hist_facs), name]  
    } else {
      # get all factors (including other non-RNA factors)
      v <- cor.mat[, name]  
    }
    # sort by absolute correlation
    v.sorted <- rev(v[order(abs(v))])
    # and get the Ntop values without the self-correlation (idx=1)
    mv <- t(as.matrix(v.sorted[2:(Ntop+1)]))
    rownames(mv) <- c(name)
    # store
    top.correlations[[name]] <- mv

    # plot without labels to have identical size of figure
    if (labels==FALSE){
      rownames(mv) <- NULL
      colnames(mv) <- NULL
    }
    corrplot(mv, method="pie", type="full", 
             tl.cex=1.0, tl.col="black", col=hmap_colors(100), insig="p-value", sig.level=-1,
             p.mat=mv, cl.pos="n")
  }
  par(mfrow=c(1,1))
  return(invisible(top.correlations))
}

# plot to file
# necessary to plot once with and without labels so that all the plots are scaled equally
pdf(file.path(resultsPath, "correlation", "histological_topcors_1.pdf"), 
    width=10, height=10, pointsize=12)  
plot_hist_topcors(method="ys3", labels=TRUE)
invisible(dev.off())
pdf(file.path(resultsPath, "correlation", "histological_topcors_2.pdf"), 
    width=10, height=10, pointsize=12)  
plot_hist_topcors(method="ys3", labels=FALSE)
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.top_correlations <- 'Figure: Top correlations to classical factors.'

## ----plot_hist_topcors_report, fig.width=10, fig.height=6, error=TRUE, htmlcap=fig.cap.top_correlations, fig.cap=fig.cap.top_correlations----
top.correlations <- plot_hist_topcors(method="ys3", labels=TRUE, mfrow=c(5,2))

## ---- fontsize="small"---------------------------------------------------
# print top correlations
options(width=200)
for (mv in top.correlations){
  print(round(mv, digits=2)) 
  cat("\n")
}
options(width=75)
rm(mv)

## ----normalize_bdl_data--------------------------------------------------
suppressPackageStartupMessages(library(matrixStats))
dir.create(file.path(resultsPath, 'cluster'), showWarnings=FALSE)

# normalize single factor
normalize_factor <- function(a, min.a, max.a, mean.a){
  res <- (a - mean.a)/(max.a - min.a)
}
# calculate min, max and mean for all single factors (normalization constants)
factor.norm <- data.frame(min=apply(BDLdata, 2, min, na.rm=TRUE), 
                            max=apply(BDLdata, 2, max, na.rm=TRUE),
                            mean=apply(BDLdata, 2, mean, na.rm=TRUE))
# function for normalizing subset of BDL data with factor normalization constants.
normalize_BDLdata <- function(data, factor.norm){
  dnorm <- data
  for (name in colnames(data)){
    dnorm[, name] <- normalize_factor(a=dnorm[, name], 
                                      min.a=factor.norm[name, "min"], 
                                      max.a=factor.norm[name, "max"],
                                      mean.a=factor.norm[name, "mean"]) 
  }
  return(dnorm)
}

# normalize full data set
BDLdata.norm <- normalize_BDLdata(data=BDLdata, factor.norm=factor.norm)
# Calculate the mean of the normalized data set
BDLmean.norm <- bdl_mean_data(BDLdata.norm, BDLsamples)

## ----plot_clusters_mean--------------------------------------------------
# Plot mean cluster with SD range and the individual representatives in the cluster.
plot_clusters_mean <- function(method){  
  # clusters for correlation method
  hc.res <- hclust.res[[method]]
  groups.hc.order <- hc.res$groups.hc.order

  # par(mfrow=c(ceiling(sqrt(Ngroups)),ceiling(sqrt(Ngroups))))
  par(mfrow=c(2,3))
  steps <- 1:Nt  # time points
  for (k in 1:Ngroups){
    # get representatives of cluster
    g <- groups.hc.order[groups.hc.order==k]
    dgroup <- BDLmean.norm[names(g)]  # normalized mean data for cluster members
  
    # mean and sd for timepoints (i.e. over all factors in the cluster) 
    g.mean <- rowMeans(as.matrix(dgroup), na.rm=TRUE)
    g.sd <- rowSds(as.matrix(dgroup), na.rm=TRUE) 
    
    # plot sd range
    plot(factor(levels(BDLsamples$time_fac), levels=levels(BDLsamples$time_fac)), 
         rep(-2, 8), type="n", xlab="", ylab="",
         xlim=c(1, Nt), ylim=1.1*c( min(min(dgroup, na.rm=TRUE), na.rm=TRUE), 
                                    max(max(dgroup, na.rm=TRUE), na.rm=TRUE) ),
         main=sprintf("%s : Cluster %s (N=%s)", method, k, ncol(dgroup)))
    polygon(c(steps, rev(steps)), c(g.mean+g.sd, rev(g.mean-g.sd)),
            col = rgb(0,0,1,0.2), border = NA)
    
    # individual data
    for (name in names(g)){
      points(steps, dgroup[, name], pch=16, col="black")
      lines(steps, dgroup[, name], col=rgb(0.5,0.5,0.5,1.0), lwd=1)
    }
    # mean over factors in cluster
    lines(steps, g.mean, col="blue", lwd=2)
  }
  par(mfrow=c(1,1))
}

# plot mean clusters to file
for (method in correlation_methods){
  pdf(file.path(resultsPath, 'cluster', sprintf("%s_cluster_mean.pdf", method)), 
        width=10, height=7.5, pointsize=12)
  plot_clusters_mean(method=method) 
  invisible(dev.off())
}

## ----echo=FALSE----------------------------------------------------------
fig.cap.mean_clusters <- 'Figure: Mean cluster time courses. Mean time course of clusters in blue, with individual mean factors in cluster in grey. Standard deviation of members in cluster is added as gray shade.'

## ----plot_clusters_mean_report, fig.width=10, fig.height=7.5, error=TRUE, htmlcap=fig.cap.mean_clusters, fig.cap=fig.cap.mean_clusters----
plot_clusters_mean(method="ys3")

## ----plot_clusters_items-------------------------------------------------
# Plot individual time courses in cluster
plot_clusters_items <- function(method, toFile=FALSE){
  # get the cluster assignment for the given method
  hc.res <- hclust.res[[method]]
  groups.hc.order <- hc.res$groups.hc.order
  
  for (k in 1:Ngroups){
    if (toFile==TRUE){
      pdf(file.path(resultsPath, "cluster", sprintf("%s_cluster_%s.pdf", method, k)), 
          width=10, height=10, pointsize=8)
    }
    g <- groups.hc.order[groups.hc.order==k]
    N <- ceiling(sqrt(length(g)))
    par(mfrow=c(N,N))
    for (name in names(g)){
      plot_single(name_A=name) 
    }
    par(mfrow=c(1,1))  
    if (toFile==TRUE){
      invisible(dev.off())
    }
  }  
}

# plot individual factors in clusters on disk
for (method in correlation_methods){
  plot_clusters_items(method=method, toFile=TRUE)  
}
rm(method)

## ----top_cluster_representatives-----------------------------------------
hmap_colors <- HeatmapColors()

# correlation between the cluster mean and cluster members
calculate_cluster_correlations <- function(method="ys3"){
  if (!identical(method, "ys3")){
    stop("Only ys3 top correlation is currently supported")
  }
  # get the clusters
  hc.res <- hclust.res[[method]]
  groups.hc.order <- hc.res$groups.hc.order
  # mean cluster time course as additional factor
  name_cluster <- sprintf("cluster.mean")
  
  # calculate top correlations for every cluster
  cluster.cor <- vector("list", length=Ngroups)
  for (k in 1:Ngroups){
      # get members of cluster
      g <- groups.hc.order[groups.hc.order==k]
      # get normalized data for members of cluster
      dgroup <- BDLdata.norm[names(g)]
      # cluster mean and add as factor (mean of all factors in cluster 
      # for given time point and sample)
      g.mean <- rowMeans(as.matrix(dgroup), na.rm=TRUE)
      dgroup[[name_cluster]] <- g.mean
      # mean averaged over repeats (for A** and M*)
      dgroup.mean <- bdl_mean_data(dgroup, BDLsamples)
      # ys3 correlation for created data.frame with mean cluster factor
      ysr.res <- ysr.matrices(dgroup.mean, BDLmean.time, use="pairwise.complete.obs")
      # Spearman correlation on individual data points
      cor.S_star <- ( cor(dgroup, method="spearman", use="pairwise.complete.obs") + 1 )/2
      # YS3 in [-1,1]
      ys3 <- 2*( (w$w1*cor.S_star + w$w2*ysr.res$A_star2 + w$w3*ysr.res$M_star) - 0.5)
      # store correlation matrix
      cluster.cor[[k]] <- ys3
  }
  return(cluster.cor)
}
cluster.cor <- calculate_cluster_correlations(method="ys3")

## ----eval=FALSE----------------------------------------------------------
#  # plot correlations for individual clusters
#  for (k in 1:Ngroups){
#    cluster.cor.mat <- cluster.cor[[k]]
#    if (ncol(cluster.cor.mat)<20){
#      corrplot(cluster.cor.mat, method="pie", type="full",
#             main=sprintf("Cluster %s", k),
#               tl.cex=0.8, tl.col="black", col=hmap_colors(100),
#               insig="p-value", sig.level=-1, p.mat=cluster.cor.mat,
#               cl.pos="n")
#    } else {
#      corrplot(cluster.cor.mat, method="circle", type="full",
#             main=sprintf("Cluster %s", k),
#               tl.cex=0.8, tl.col="black", col=hmap_colors(100),
#               cl.pos="n")
#    }
#  }
#  rm(k, cluster.cor.mat)

## ----top_cluster_correlations--------------------------------------------
plot_top_cluster_representatives <- function(method="ys3", Ntop=11, labels=TRUE){
  par(mfrow=c(Ngroups,1))
  name_cluster <- sprintf("cluster.mean")
  for (k in 1:Ngroups){
      # YS3 in [-1,1]
      ys3 <- cluster.cor[[k]]
  
      # correlation for the cluster mean
      v <- ys3[, which(colnames(ys3)==name_cluster)]
      # sort by absolute correlation
      v.sorted <- rev(v[order(abs(v))])

      # reduce to Ntop candidates and fill short clusters with zeros tto Ntop
      if (length(v.sorted)>=(Ntop+1)){
        v.sorted <- v.sorted[2:(Ntop+1)]
      } else {
        v.sorted <- c(v.sorted[2:length(v.sorted)], rep(0,Ntop-length(v.sorted)+1))
      }
      # prepare data for corrplot
      mv <- t(as.matrix(v.sorted))
      rownames(mv) <- c(paste(name_cluster, k))
      if (labels == FALSE){
        colnames(mv) <- NULL
      }
      corrplot(mv, method="pie", type="full", 
             tl.cex=1.0, tl.col="black", col=hmap_colors(100), 
             insig="p-value", sig.level=-1, p.mat=mv,
             cl.pos="n")
  }
  par(mfrow=c(1,1))
}

# plot to file (with and without names)
pdf(file.path(resultsPath, "cluster", "cluster_top_representatives_01.pdf"), 
    width=5, height=5, pointsize=12)
plot_top_cluster_representatives(labels=FALSE)
invisible(dev.off())
pdf(file.path(resultsPath, "cluster", "cluster_top_representatives_02.pdf"), 
    width=10, height=10, pointsize=12)
plot_top_cluster_representatives(labels=TRUE)
invisible(dev.off())


## ----echo=FALSE----------------------------------------------------------
fig.cap.top_clusters <- 'Figure: Top cluster correlations. Top correlations between the respective cluster mean and the members in the cluster sorted by absolute correlation.'

## ----plot_clusters_top_correlations, fig.width=10, fig.height=7, error=TRUE, htmlcap=fig.cap.top_clusters, fig.cap=fig.cap.top_clusters----
plot_top_cluster_representatives(labels=TRUE)

## ----ys3_cluster_table---------------------------------------------------
# print representatives of cluster
list_cluster_information <- function(method="ys3"){
  if(!identical(method, "ys3")){
    stop("Cluster correlation only calculated for ys3")
  }
  groups <- hclust.res[[method]]$groups
  cat(sprintf("------------------------------------------\n"))
  cat(sprintf("Correlation method: *** %s ***\n", method))
  cat(sprintf("------------------------------------------\n"))
  for (k in 1:Ngroups){
    cluster.cor.mat <- cluster.cor[[k]]
    # create data.frame with ANOVA & cluster correlation
    g <- groups[groups==k]
    cat(sprintf("Cluster %s (N=%s)\n", k, length(g)))
    Ng <- length(names(g))
    rows <- vector("list", length=Ng)
    for (kn in 1:Ng){
      name <- names(g)[kn]
      row <- df.anova[which(df.anova$factor==name),]
      row$cluster.cor <- cluster.cor.mat[name, "cluster.mean"]
      rows[[kn]] <- row
    }
    df <- do.call("rbind", rows)
    df <- df[order(-df$cluster.cor), ]

    # cleanup the data.frame
    rownames(df) <- df$factors
    df <- df[, c("p.holm", "sig.holm", "ftype", "fshort", "cluster.cor")]
    df$cluster.cor <- round(df$cluster.cor, digits=2)
    df$p.holm <- sprintf("%1.2E", df$p.holm)
    print(df)
    
    cat("\n")
    # create list for figure legend
    # print(paste(sprintf("%s (%s)", rownames(df), df$cluster.cor),
    #            sep=", ", collapse =", " ))
  }  
}

## ----fontsize="small"----------------------------------------------------
# List information in cluster
list_cluster_information(method="ys3")

## ------------------------------------------------------------------------
#

## ----decision_tree_folder------------------------------------------------
suppressPackageStartupMessages(library(rpart))
suppressPackageStartupMessages(library(rpart.plot))
suppressPackageStartupMessages(library(caret))
dir.create(file.path(resultsPath, 'decision_tree'), showWarnings=FALSE)

## ----log_transformation--------------------------------------------------
# transform data to log scale
log_transform <- function(data){
  log(data+1)
}
# back transformation
log_transform_back <- function(log_data){
  exp(log_data)-1
}
# resulting time transformations
time_transformation <- data.frame(time=BDLmean.time, 
                                  log_time=log_transform(BDLmean.time))
print(round(time_transformation, 2))

## ----tree_trainings_data-------------------------------------------------
  prepare_treedata_mean <- function(method="ys3"){
  # Hierarchical clusters based on ys3 to fit the regression tree
  hc.res <- hclust.res[[method]]
  groups <- hc.res$groups
  
  # Prepare training set for fitting the decision trees (mean cluster data set, 
  # i.e. mean over normalized factors in cluster).
  na.vec <- rep(NA, Nt*Nr)
  treedata.mean <- data.frame(c1=na.vec, c2=na.vec, c3=na.vec, 
                              c4=na.vec, c5=na.vec, c6=na.vec)
  # for every sample
  for (ks in 1:(Nt*Nr)){
    # create the mean over the cluster
    for (kgroup in 1:Ngroups){
      # get factors in the cluster
      factors <- names(groups[groups==kgroup])
      # calculate mean over normalized data
      treedata.mean[ks, kgroup] <- mean(as.numeric(BDLdata.norm[ks, factors]), na.rm=TRUE)
    }
  }
  # add log transformed time [h] for regression
  treedata.mean$logtime <- log_transform(BDLsamples$time)
  # add experimental time class
  treedata.mean$class <- BDLsamples$time_fac
  return(treedata.mean)
}
treedata.mean <- prepare_treedata_mean()

# save the trainings data
save(treedata.mean, file=file.path(resultsPath, "data", "treedata.mean.Rdata"))

## ----fontsize="small"----------------------------------------------------
# mean cluster data set for model fitting
options(width=200)
print(round(treedata.mean[, -8], digits=2))
options(width=75)

## ----fit_regression_tree-------------------------------------------------
# formula for regression tree
formula.reg = paste("logtime ~ c1 + c2 + c3 + c4 + c5 + c6")

# fit regression tree with mean cluster data
tree.reg <- rpart(formula=formula.reg, 
                  data=treedata.mean, 
                  method="anova", 
                  control=rpart.control(minsplit=6, minbucket=2, cp=0.01))

# pretty plot of tree to file
pdf(file.path(resultsPath, 'decision_tree', "regression_tree.pdf"), 
    width=10, height=5, pointsize=12)  
prp(tree.reg, type=0, extra=101, yesno=TRUE)
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.tree_prp <- 'Figure: Regression tree on mean clusters. Fitted regression tree on the mean cluster data, predicting the log time classes. Splitting points are on the mean cluster values.'

## ----plot_tree_prp, fig.width=7, fig.height=7, error=TRUE, htmlcap=fig.cap.tree_prp, fig.cap=fig.cap.tree_prp----
# plot of regression tree
prp(tree.reg, type=0, extra=101, yesno=TRUE)
# visualize cross-validation results 
# rsq.rpart(tree.reg) 

## ----fontsize="tiny"-----------------------------------------------------
# detailed overview of the resulting tree
options(width=200)
print(tree.reg)
summary(tree.reg)
printcp(tree.reg)
tree.reg$frame
options(width=75)

## ----variables_in_tree---------------------------------------------------
# variables used for splitting in the decision tree
tree.nodes <- (tree.reg$frame)$var
tree.nodes <- tree.nodes[tree.nodes != "<leaf>"]
tree.vars <- as.character(sort(unique(tree.nodes)))
rm(tree.nodes)
# variables used for splitting decisions in tree
print(tree.vars)

## ----leave_one_out_tree--------------------------------------------------
# in total 40 cross validations (individual mice are not followed through time)
trees.test <- vector("list", length=Nr*Nt)  # fitted trees
pred.test.log <- rep(NA, length=Nr*Nt)
for (k in 1:(Nr*Nt)){
  # delete the k index
  idx.subset <- 1:(Nr*Nt)
  idx.subset <- idx.subset[-k]
  
  # fit tree with the subset
  t.test <- rpart(formula=formula.reg, 
                  data=treedata.mean[idx.subset, ], 
                  method="anova", 
                  control=rpart.control(minsplit=6, minbucket=2, cp=0.01))  
  trees.test[[k]] <- t.test
  
  # prediction on left out sample
  pred.test.log[k] <- predict(t.test, newdata=treedata.mean[k,], type="vector")
}
# transformation to time in [h]
pred.test <- log_transform_back( pred.test.log )

plot_cross_validation <- function(){
# plot the log prediction and error
  par(mfrow=c(1,2))
  plot(log_transform(BDLsamples$time), log_transform(pred.test),
       main="Leave one out cross validation",
       xlim=c(0,7), ylim=c(0,7),
       xlab="log(time_exp)",
       ylab="log(time_pre)")
  abline(a=0, b=1, col="gray")
  textxy(log_transform(BDLsamples$time), log_transform(pred.test), 
         1:(Nr*Nt), col="black", cex=0.6)
  
  plot(log_transform(BDLsamples$time), 
       log_transform(BDLsamples$time)-log_transform(pred.test),
       main="Prediction error",
       xlab="log(time_exp)",
       ylab="log(time_exp)-log(time_pre)",
       xlim=c(0,7), ylim=c(-1.5, 1.5))
  abline(a=0, b=0, col="gray")
  textxy(log_transform(BDLsamples$time), 
         log_transform(BDLsamples$time)-log_transform(pred.test), 
         1:(Nr*Nt), col="black", cex=0.6)
  par(mfrow=c(1,1))  
}

## ----echo=FALSE----------------------------------------------------------
fig.cap.tree_cv <- 'Figure: Cross validation predictions. Predictions on the left out data set with the fitted tree.'

## ----plot_tree_cv,  htmlcap=fig.cap.tree_cv, fig.cap=fig.cap.tree_cv-----
plot_cross_validation()

## ----prediction_distance-------------------------------------------------
# L2 (euclidian) distance measurement on the log transformed data. 
# Analog to the distance measurement in fitting the regression tree.
log_distance <- function(d1, d2){
  # sums over all the distances of the samples in log space
  log_rmsd <- sqrt(sum( (log_transform(d1)-log_transform(d2) )^2 ))/length(d1)
  return(log_rmsd)
}

## ----predict_trainings_data----------------------------------------------
# mean cluster predictions
pred.mean.log <- predict(tree.reg, newdata=treedata.mean, type="vector")
# transformation to time in [h]
pred.mean <- log_transform_back( pred.mean.log )

# Distance calculation (predicted to experimental)
dist.mean.all <- treedata.mean$logtime - pred.mean.log
dist.mean <- log_distance(pred.mean, BDLsamples$time)

# plot predicted ~ experimentell
plot_mean_prediction <- function(){
  par(mfrow=c(1,2))
  plot(BDLsamples$time, pred.mean, pch=15, col=rgb(0,0,1, 0.2), 
       main="Regression Tree:\nPredicted ~ experimentell time",
       xlab="experimentell time [h]", ylab="predicted time [h]")
  abline(a=0, b=1, col=rgb(0.5,0.5,0.5,0.5))
  hist(dist.mean.all, breaks=seq(from=-1.05, to=1.05, by=0.1), 
       main="Histogram prediction error:\nmean cluster data",
       col=rgb(0.5,0.5,0.5,0.5),
       xlab="logtime(exp)-logtime(pred)")
  par(mfrow=c(1,1))  
}
# plot to file
pdf(file.path(resultsPath, 'decision_tree', "prediction_mean.pdf"), 
    width=10, height=5, pointsize=12)  
plot_mean_prediction()
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.mean_prediction <- 'Figure: Predictions on mean cluster data. Predictions using the mean cluster data. This is the trainings data and results in the best performing tree.'

## ----plot_mean_prediction, htmlcap=fig.cap.mean_prediction, fig.cap=fig.cap.mean_prediction----
plot_mean_prediction()

## ----tree_class_ranges---------------------------------------------------
calculate_node_ranges <- function(){
  # classes via predicted classes for cluster data
  node_levels <- levels(as.factor(pred.mean))
  # These are the predicted classes
  node_classes <- round(as.numeric(node_levels), digits=1)
  
  # get the intervals of the time classes
  node_mean <- as.numeric(levels(as.factor(pred.mean.log)))
  node_midpoints <- (node_mean[2:length(node_mean)]+node_mean[1:(length(node_mean)-1)])/2
  # minimum of range
  node_min <- node_mean
  node_min[2:length(node_min)] <- node_midpoints
  # maximum of range
  node_max <- node_mean
  node_max[1:(length(node_min)-1)] <- node_midpoints
  # ranges in log scale
  node_ranges.log <- data.frame(node_mean, node_min, node_max)
  
  node_ranges <- data.frame(mean=log_transform_back(node_mean), 
                            min=log_transform_back(node_min),
                            max=log_transform_back(node_max))
  rownames(node_ranges) <- paste("class", 1:nrow(node_ranges))
  return(node_ranges)
}

# predicted time classes by decision tree
node_ranges <- calculate_node_ranges()
print(round(node_ranges, digits=1))

## ----single_factor_data--------------------------------------------------
# names of factors in the clusters
cluster_names <- paste('c', 1:Ngroups, sep="")
cluster.factors <- vector("list", length=Ngroups)
groups <- (hclust.res$ys3)$groups  # get the ys3 groups
for (k in 1:Ngroups){
  cluster.factors[[k]] <- as.character(names(groups[groups==k]))
}
names(cluster.factors) <- cluster_names

# create data.frame of all single combinations from clusters
single.combinations <- expand.grid(cluster.factors, stringsAsFactors=TRUE)
names(single.combinations) <- names(cluster.factors)
# number of single combinations
Nsingle <- nrow(single.combinations)

# create all single factor data
print("Calculating single factor data (~ 3min) ... ")
ptm <- proc.time()  
treedata.single <- vector("list", Nsingle)  # list for all combinations
for (k in 1:Nsingle){
  # ----------------------------------------------------------------
  # THIS HAS TO BE FAST (<0.005 s)
  # ----------------------------------------------------------------
  # ptm <- proc.time() # Start the clock!
  # get factor data
  tmp <- BDLdata.norm[, t(single.combinations[k, ]) ]
  # add regression values
  tmp[c("class", "logtime")] <- treedata.mean[ c("class", "logtime")]
  # add factor fields 
  tmp[, paste(cluster_names, '.id', sep="")] <- single.combinations[k,]
  colnames(tmp) <- c(cluster_names, 'class', 'logtime', paste(cluster_names, '.id', sep=""))
  # store data 
  treedata.single[[k]] <- tmp
  # if (k%%500 == 0){print(k)} 
  # print(proc.time()-ptm)  # Stop the clock
}
# Stop the clock
rm(tmp,k)
print(proc.time() - ptm)

# which factor combinations only use genes
factor_is_gene <- BDLfactors$ftype %in% c("GE_ADME", "GE_Cytokines", "GE_Fibrosis")
names(factor_is_gene) <- BDLfactors$id
# vector for lookup if only genes were used
gene_only.single <- vector("logical", Nsingle)
for (k in 1:Nsingle){
  gene_only.single[k] <- all(factor_is_gene[t(single.combinations[k,])])
}
rm(k)

## ----double_factor_data--------------------------------------------------
print("Calculating double factor data (~ 1min) ... ")
ptm <- proc.time()
set.seed(123456)
Ndouble <- 10000
treedata.double <- vector("list", Ndouble)  # list for sampled double combinations
for (k in 1:Ndouble){
  # sample from the 4 clusters without replacement
  n1 = sample(cluster.factors[[1]], 2, replace=FALSE)  
  n2 = sample(cluster.factors[[2]], 2, replace=FALSE)  
  n3 = sample(cluster.factors[[3]], 2, replace=FALSE)  
  n4 = sample(cluster.factors[[4]], 2, replace=FALSE)  
  n5 = sample(cluster.factors[[5]], 2, replace=FALSE)  
  n6 = sample(cluster.factors[[6]], 2, replace=FALSE)  
  # The mean of the combination is used (handle NAs)
  tmp <- 0.5 * (  BDLdata.norm[, c(n1[1], n2[1], n3[1], n4[1], n5[1], n6[1])] 
                + BDLdata.norm[, c(n1[2], n2[2], n3[2], n4[2], n5[2], n6[2])] )
   # add class and regression values
  tmp[c("class", "logtime")] <- treedata.mean[ c("class", "logtime")]
  # add factor fields 
  tmp[ , paste(cluster_names, '.id', sep="")] <- data.frame(paste(n1, collapse="__"), 
                                              paste(n2, collapse="__"),
                                              paste(n3, collapse="__"),
                                              paste(n4, collapse="__"),
                                              paste(n5, collapse="__"),
                                              paste(n6, collapse="__"))
  colnames(tmp) <- c(cluster_names, 'class', 'regvalue', 
                     paste(cluster_names, '.id', sep=""))
  # store data
  treedata.double[[k]] <- tmp
}
rm(k, tmp)
print(proc.time() - ptm)

## ----single_prediction---------------------------------------------------
print("Predicting single factor data (~ 2min) ... ")
pred.single.all <- vector("list", length(treedata.single))
for (k in (1:length(treedata.single))){
  # prediction and back transformation  
  pred.single.all[[k]] <- log_transform_back( predict(tree.reg, newdata=treedata.single[[k]], method="anova") )
}
pred.single <- do.call("rbind", pred.single.all)

# distance for all predictions on single factor per cluster
dist.single <- rep(NA, Nsingle)
for (k in 1:Nsingle){
  dist.single[k] <- log_distance(pred.single[k,], BDLsamples$time)
}

## ----double_prediction---------------------------------------------------
print("Predicting double factor data (~ 1min) ... ")
pred.double.all <- vector("list", length(treedata.double))
for (k in (1:length(treedata.double))){
  pred.double.all[[k]] <- log_transform_back( predict(tree.reg, newdata=treedata.double[[k]], method="anova") )
}
pred.double <- do.call("rbind", pred.double.all)

# distance for predictions on 2 sampled factors per cluster 
dist.double <- rep(NA, Ndouble)
for (k in 1:Ndouble){
  dist.double[k] <- log_distance(pred.double[k,], BDLsamples$time)
}

## ----best_trees----------------------------------------------------------
# Best decision tree using all factors (minimal distance)
dist.rep.best <- min(dist.single)
# best combination of representatives for the clusters (remove duplicates)
rep.best <- unique(single.combinations[which(dist.single==dist.rep.best), 
                                       c("c1", "c3", "c4", "c5")])
rep.best.idx <- rownames(rep.best)[1]
# predictions of best representative
pred.rep.best <- pred.single[as.numeric(rep.best.idx), ]

print("Best single representatives for decision tree:")
print(rep.best)
print(dist.rep.best)
# ------------------------
# Best decision tree using only gene factors, i.e. first reduce to the gene combinations
dist.single.genes <- dist.single[gene_only.single]
single.combinations.genes <- single.combinations[gene_only.single,]
dist.gene.best <- min(dist.single.genes)
# find best gene combination
gene.best <- unique(single.combinations.genes[which(dist.single.genes==dist.gene.best), 
                                              c("c1", "c3", "c4", "c5")])
# predictions with best representative
gene.best.idx <- rownames(gene.best)
pred.gene.best <- pred.single[as.numeric(gene.best.idx), ]

print("Best single representatives based on genes for decision tree:")
print(gene.best)
print(dist.gene.best)
# ------------------------
# Plot time courses of the representatives/factors in provided tree combinations
plot_tree_representatives <- function(combination){
  Nc <- ncol(combination)
  Nr <- nrow(combination)
  par(mfrow=c(Nr, Nc))
  for (kr in 1:Nr){
    for (kc in 1:Nc){
      cluster <- colnames(combination)[kc]
      name <- as.character(combination[kr, kc])
      plot_single(name)
    }  
  }
  par(mfrow=c(1,1))
}

# plot to file
pdf(file.path(resultsPath, "decision_tree", "rep.best.representatives.pdf"), 
    width=10, height=6, pointsize=12)
plot_tree_representatives(rep.best)
invisible(dev.off())
pdf(file.path(resultsPath, "decision_tree", "gene.best.representatives.pdf"), 
    width=10, height=3, pointsize=12)
plot_tree_representatives(gene.best)
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.tree_factors_all <- 'Figure: Best factor combination using all factors. Two alternative solutions for the single factor combinations.'

## ----plot_tree_all,  fig.height=9, htmlcap=fig.cap.tree_factors_all, fig.cap=fig.cap.tree_factors_all----
plot_tree_representatives(rep.best)

## ----echo=FALSE----------------------------------------------------------
fig.cap.tree_factors_gene <- 'Figure: Best factor combination using transcript factors.'

## ----plot_tree_gene,  fig.height=4.5, htmlcap=fig.cap.tree_factors_gene, fig.cap=fig.cap.tree_factors_gene----
plot_tree_representatives(gene.best)

## ----tree_distance_distribution------------------------------------------
# distance histogram
plot_tree_distance_dist <- function(){
  breaks <- seq(from=0, to=0.40, by=0.0125)
  hist(dist.single, freq=FALSE, breaks=breaks,
      main="Prediction error",
      xlab="RMSD(time.predicted, time.exp)",
      col=rgb(0.7,0.7,0.7, 1),
      ylim=c(0,15)
  )
  hist(dist.double, freq=FALSE, breaks=breaks,
       col=rgb(1,0,0, 0.5), add=TRUE)
  
  abline(v=dist.mean, col=rgb(0,0,1, 0.5), lwd=2)
  abline(v=dist.rep.best, col="black", lwd=2)
  abline(v=dist.gene.best, col="grey", lwd=2)
  
  legend("topright", legend=c("single factor", "double factor", "mean cluster"), 
             col=c(rgb(0.7, 0.7, 0.7, 1),rgb(1, 0, 0, 0.5),rgb(0, 0, 1, 0.5)),
             bty="n", cex=1.0, pch=15)
}
# plot to file
pdf(file.path(resultsPath, "decision_tree", "tree_distance_distribution.pdf"), 
    width=10, height=6, pointsize=14)
plot_tree_distance_dist()
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.tree_distance <- 'Figure: Prediction error of regression tree. Distribution of distances for single factor combinations, double factor combinations, mean cluster data, best gene factor combination, and best all factor combination. Adding additional factors to the prediction improves the predictions.'

## ----plot_tree_distance,  fig.height=4.5, htmlcap=fig.cap.tree_distance, fig.cap=fig.cap.tree_distance----
plot_tree_distance_dist()

## ----barplot_predictions-------------------------------------------------
# Predicted classes of the regression tree
node_levels <- levels(as.factor(pred.mean))
node_classes <- round(as.numeric(node_levels), digits=1)

# Plot of the predicted classes with the decision tree
plot_predicted_classes <- function(){
  # bar_colors <- brewer.pal(4, "Set3")
  bar_colors <- c(rgb(0.9,0.9,0.9), 
                  rgb(0.7,0.7,0.7),
                  rgb(1,0,0, 0.5),
                  rgb(0,0,1, 0.5))
  par(mfrow=c(2,4))
  for (k in 1:Nt){
    # single factor predictions
    data <- as.vector(pred.single[, ((1:Nr)+Nr*(k-1))])
    tab.single <- table(factor(data, levels=node_levels))/length(data)
    # two factor predictions
    data <- as.vector(pred.double[, ((1:Nr)+Nr*(k-1))])
    tab.double <- table(factor(data, levels=node_levels))/length(data)
    # mean cluster predictions
    data <- as.vector(pred.mean[((1:Nr)+Nr*(k-1))])
    tab.mean <- table(factor(data, levels=node_levels))/length(data)
    # best single gene representative
    data <- as.vector(pred.gene.best[((1:Nr)+Nr*(k-1))])
    tab.gene.best <- table(factor(data, levels=node_levels))/length(data)
    
    # combined table
    tab <- rbind(tab.single, tab.double, tab.gene.best, tab.mean)
    colnames(tab) <- round(as.numeric(colnames(tab)), digits=1)
    
    # create the bar plot
    name <- sprintf("Time after BDL: %sh", levels(as.factor(BDLsamples$time))[k])
    barplot(tab, beside=TRUE,
            main=name, 
            xlab="predicted time class [h]", ylab="fraction of predictions",
            ylim=c(0,1), col=bar_colors) 
    if (k==1){
      legend("topright", legend=c("single factors", "double factors", 
                                  "best single gene", "mean cluster"), 
             col=bar_colors,
             bty="n", cex=1.0, pch=15)
    }
  }
  par(mfrow=c(1,1))
}

## ----echo=FALSE----------------------------------------------------------
fig.cap.tree_bar1 <- 'Figure: Prediction performance of regression tree.'

## ----plot_tree_bar1,  fig.height=6, htmlcap=fig.cap.tree_bar1, fig.cap=fig.cap.tree_bar1----
plot_predicted_classes()

## ------------------------------------------------------------------------
# reverse bar plot
library(plyr)
library(reshape2)

# which experiments are predicted in which class
plot_predicted_classes2 <- function(){
  bar_colors <- c(rgb(1,1,1), 
                  rgb(0.8,0.8,0.8),
                  rgb(1,0,0, 0.5),
                  rgb(0,0,1, 0.5))
  # single
  df <- data.frame(exp=rep(BDLsamples$time, Nsingle), 
                 pre=as.vector(t(round(pred.single, digits=1))) )
  tmp <- count(df, c("exp", "pre"))
  tab.single <- acast(tmp, exp~pre, value.var="freq", fill=0)
  # double
  df <- data.frame(exp=rep(BDLsamples$time, Ndouble), 
                 pre=as.vector(t(round(pred.double, digits=1))) )
  tmp <- count(df, c("exp", "pre"))
  tab.double <- acast(tmp, exp~pre, value.var="freq", fill=0)
  # best gene
  df <- data.frame(exp=rep(BDLsamples$time, 1), 
                 pre=as.vector(t(round(pred.gene.best, digits=1))) )
  tmp <- count(df, c("exp", "pre"))
  tab.gene.best <- acast(tmp, exp~pre, value.var="freq", fill=0)
  # mean cluster
  df <- data.frame(exp=rep(BDLsamples$time, 1), 
                 pre=as.vector(t(round(pred.mean, digits=1))) )
  tmp <- count(df, c("exp", "pre"))
  tab.mean <- acast(tmp, exp~pre, value.var="freq", fill=0)  

  par(mfrow=c(2,3))  
  for (k in 1:length(node_classes)){
    # combined table (normalized within each class)
    tab <- rbind(tab.single[,k]/sum(tab.single[,k]),
                 tab.double[,k]/sum(tab.double[,k]), 
                 tab.gene.best[,k]/sum(tab.gene.best[,k]),
                 tab.mean[,k]/sum(tab.mean[,k]))

    # create the bar plot
    name <- sprintf("Predicted: %sh", node_classes[k])
    barplot(tab, beside=TRUE,
            main=name, 
            xlab="time after BDL [h]", ylab="fraction",
            ylim=c(0,1), col=bar_colors) 
    if (k==1){
      legend("topright", legend=c("single factors", "double factors", 
                                  "best gene", "mean cluster"), 
             col=bar_colors,
             bty="n", cex=1.0, pch=15)
    }
  }
  par(mfrow=c(1,1))
}

# barplot to file
pdf(file.path(resultsPath, "decision_tree", "predicted_classes2.pdf"), 
    width=12, height=7.5, pointsize=14)
plot_predicted_classes2()
invisible(dev.off())

## ----echo=FALSE----------------------------------------------------------
fig.cap.tree_bar2 <- 'Figure: Prediction performance of regression tree.'

## ----plot_tree_bar2,  fig.height=6, htmlcap=fig.cap.tree_bar2, fig.cap=fig.cap.tree_bar2----
plot_predicted_classes2()

